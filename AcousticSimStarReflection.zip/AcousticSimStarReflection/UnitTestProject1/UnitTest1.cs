﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using AcousticSimStarReflection;

using MathNet.Numerics.LinearAlgebra;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void クラス生成テスト()
        {
            var sim = new Class2DAcoustics();
            // 初期化
            sim.Reset();
            //データゲット
            Matrix<double> Pxy = sim.GetP();
            // 0行列
            Matrix<double> __Pxy = Matrix<double>.Build.Dense(Class2DAcoustics.N, Class2DAcoustics.N);
            // テスト
            Assert.AreEqual(Pxy, __Pxy);
        } // クラス生成テスト



        [TestMethod]
        public void 変数テスト()
        {
            var sim = new Class2DAcoustics();

            var n = Class2DAcoustics.N;
            var c = sim.C;
            var dt = sim.dt;
            var dd = sim.dd;
        } // 変数テスト



        [TestMethod]
        public void 初期化テスト()
        {
            var sim = new Class2DAcoustics();
            // 初期化
            sim.Reset();
            //データゲット
            Matrix<double> Pxy = sim.GetP();
            // 0行列
            Matrix<double> __Pxy = Matrix<double>.Build.Dense(Class2DAcoustics.N, Class2DAcoustics.N);
            // テスト
            Assert.AreEqual(Pxy, __Pxy);
        }



        [TestMethod]
        public void 初期化テスト2()
        {
            var sim = new Class2DAcoustics();
            // 初期化
            sim.Reset();
            sim.Step(1);
            //データゲット
            Matrix<double> Pxy = sim.GetP();
            // 0行列
            Matrix<double> __Pxy = Matrix<double>.Build.Dense(Class2DAcoustics.N, Class2DAcoustics.N);
            // テスト
            Assert.AreNotEqual(Pxy, __Pxy); // 0ではない
        } // 初期化テスト


        [TestMethod]
        public void ステップテスト()
        {
            var sim = new Class2DAcoustics();

            sim.Reset();
            Assert.AreEqual(sim.t, 0);

            sim.Step(1);
            Assert.AreEqual(sim.t, 1);

            sim.Step(10);
            Assert.AreEqual(sim.t, 11);

            sim.Reset();
            Assert.AreEqual(sim.t, 0);

            sim.Step(100);
            Assert.AreEqual(sim.t, 100);


        } // 初期化テスト

    }
}
