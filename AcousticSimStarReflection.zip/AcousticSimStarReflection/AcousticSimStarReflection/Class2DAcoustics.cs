﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MathNet.Numerics.LinearAlgebra;

namespace AcousticSimStarReflection
{
    public class Class2DAcoustics
    {

        public const int N = 300;          //系の長さ
        public double C = 1;           //波の速度
        public double dt = 0.1;          //時間の刻み幅
        public double dd = 2.0;          //系の刻み幅
        public double BCR = (3.0 / 4.0) * N/2.0; // BC半径
        public int t = 0;
        public Matrix<double> P = Matrix<double>.Build.Dense(N, N);
        double[][][] z; // [2]が最新情報

        // コンストラクタ
        public Class2DAcoustics()
        {
            // 初期化
            Reset();
        }

        // 初期化
        public void Reset()
        {
            // 初期化
            P = Matrix<double>.Build.Dense(N, N);

            // ジャグ配列 z 初期化
            z = new double[3][][];
            for (int ai = 0; ai < 3; ai++)
            {
                z[ai] = new double[N][];
                for (int bi = 0; bi < N; bi++)
                {
                    z[ai][bi] = new double[N];
                    for (int ci = 0; ci < N; ci++)
                    {
                        z[ai][bi][ci] = 0.0;
                    }
                }
            }

            /* タイムステップ初期化 */
            this.t = 0;

            double g;
            double sigma = 10;

            /*波の初期条件の決定*/
            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    //ガウスで初期化
                    z[0][i][j] = Math.Exp(-1.0 * (Math.Pow(i - N / 2.0, 2) + Math.Pow(j - N / 2.0, 2)) / sigma);

                }
            } // 波の初期条件の決定

            /* 初期状態から次の状態を計算する */
            for (int i = 1; i < N - 1; i++)
            {
                for (int j = 1; j < N - 1; j++)
                {
                    z[1][i][j] = z[0][i][j] + C * C / 2.0 * dt * dt / (dd * dd)
                        * (z[0][i + 1][j] + z[0][i - 1][j] + z[0][i][j + 1] + z[0][i][j - 1] - 4.0 * z[0][i][j]);
                }
            }

            /* 境界条件1 */
            for (int i = 0; i < N; i++)
            {
                z[1][i][0] = z[1][i][N - 1] = z[1][0][i] = z[1][N - 1][i] = 0.0;    //境界条件
            }

            // 境界条件2
            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    // 半径R以上
                    if (Math.Sqrt((i - N / 2.0) * (i - N / 2.0) + (j - N / 2.0) * (j - N / 2.0)) > (double)BCR)
                        z[1][i][j] = 0.0;

                }
            }

        }

        public void Step(int step)
        {
            for (int i = 0; i < step; i++)
            {
                this._Step();
            }
        }

        public void _Step()
        {

            /*以降の波の状態を計算する*/
            this.t++;

            // 時間更新
            for (int i = 1; i < N - 1; i++)
            {
                for (int j = 1; j < N - 1; j++)
                {
                    z[2][i][j] = 2.0 * z[1][i][j] - z[0][i][j] + C * C * dt * dt / (dd * dd)
                        * (z[1][i + 1][j] + z[1][i - 1][j] + z[1][i][j + 1] + z[1][i][j - 1] - 4.0 * z[1][i][j]);
                }
            }

            // 境界条件
            for (int i = 0; i < N; i++)
            {
                z[2][i][0] = z[2][i][N - 1] = z[2][0][i] = z[2][N - 1][i] = 0.0;    //境界条件
            }
            // 境界条件2
            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    // 半径R以上
                    if (Math.Sqrt((i - N / 2.0) * (i - N / 2.0) + (j - N / 2.0) * (j - N / 2.0)) > (double)BCR)
                        z[2][i][j] = 0.0;
                }
            }

            /*次の計算のために配列の数値を入れかえる。ここで過去の情報は失われる。*/
            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    z[0][i][j] = z[1][i][j];
                    z[1][i][j] = z[2][i][j];
                }
            }

        }// Step

        public Matrix<double> GetP()
        {
            // コピー
            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    P[i, j] = z[2][i][j];
                }
            }
            return P;
        }




    }
}
