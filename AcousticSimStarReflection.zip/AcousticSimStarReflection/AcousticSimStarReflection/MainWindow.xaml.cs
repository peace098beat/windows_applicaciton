﻿using MathNet.Numerics.LinearAlgebra;
using System;
using System.Windows;
using AcousticSimStarReflection;

namespace AcousticSimStarReflection
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {

        # region Acoustic
        Class2DAcoustics sim = new Class2DAcoustics();
        int PN = Class2DAcoustics.N;
        Matrix<double> Pi = Matrix<double>.Build.Dense(Class2DAcoustics.N, Class2DAcoustics.N);
        # endregion

        public MainWindow()
        {
            InitializeComponent();

        } // MainWindow

        public void updateSimulation()
        {
            int n_step = Convert.ToInt16(textBox_step.Text);
            sim.Step(n_step);

            int now_step = sim.t;

            // コピー
            Pi = sim.GetP();
            double s = Pi.ColumnSums().Sum();

            textBox.Text = string.Format("Step数:{0}, Sum:{1:0.00}", now_step, s);

            glControl_Update();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            updateSimulation();

        } // button_Click

        private void btn_reset_Click(object sender, RoutedEventArgs e)
        {
            sim.Reset();
            updateSimulation();
        }

        private void btn_anim_Click(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < 100; i++)
            {
                updateSimulation();
                textBox.Text = string.Format("Anim Step : {0}", i);

            }
        }


    }
}
