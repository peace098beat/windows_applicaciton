﻿using MathNet.Numerics.LinearAlgebra;
using System;
using System.Windows;

namespace NDof3DManipulatorFK
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {

        // Kinematis 計算用
        public IK ik = new IK();
        const double LINK_LENGTH = 0.8; // リンク長さ

        const int N_JOINT = 7;
        const int N_LINK = N_JOINT; // リンク数 + 原点位置ベクトル
        Vector<double>[] Links; // 各リンクの初期位置 [x,y,z]
        Vector<double>[] Angles; // 初期角度 [rad]
        // 描画関連
        public double[,] Pi = new double[N_JOINT, 3]; // 描画用ジョイント位置

        public MainWindow()
        {
            InitializeComponent();

            // 各リンクの初期位置 [x,y,z]
            Links = new Vector<double>[N_LINK]
            {
                Vector<double>.Build.DenseOfArray(new double[3] {1,1,0}),
                Vector<double>.Build.DenseOfArray(new double[3] {0,0,LINK_LENGTH}),
                Vector<double>.Build.DenseOfArray(new double[3] {0,0,LINK_LENGTH}),
                Vector<double>.Build.DenseOfArray(new double[3] {0,0,LINK_LENGTH}),
                Vector<double>.Build.DenseOfArray(new double[3] {0,0,LINK_LENGTH}),
                Vector<double>.Build.DenseOfArray(new double[3] {0,0,LINK_LENGTH}),
                Vector<double>.Build.DenseOfArray(new double[3] {0,0,LINK_LENGTH})
            };

            // 初期角度 [rad]
            Angles = new Vector<double>[N_JOINT]
            {
                Vector<double>.Build.DenseOfArray(new double[3] {0,0,0}),
                Vector<double>.Build.DenseOfArray(new double[3] {0,0,0}),
                Vector<double>.Build.DenseOfArray(new double[3] {0,0,0}),
                Vector<double>.Build.DenseOfArray(new double[3] {0,0,0}),
                Vector<double>.Build.DenseOfArray(new double[3] {0,0,0}),
                Vector<double>.Build.DenseOfArray(new double[3] {0,0,0}),
                Vector<double>.Build.DenseOfArray(new double[3] {0,0,0})
            };

            // 初期計算
            UpdateIK();
        } // MainWindow

        private void UpdateIK()
        {
            // 順運動学計算
            Vector<double>[] FK_P = ik.ForwardKinematic(N_LINK, Links, Angles);
            // 描画用にジョイント位置を格納
            for (int i = 0; i < FK_P.Length; i++)
            {
                Pi[i, 0] = FK_P[i][0];
                Pi[i, 1] = FK_P[i][1];
                Pi[i, 2] = FK_P[i][2];
            }
            // リンク長さ一定保障
            for (int i = 1; i < FK_P.Length; i++)
            {
                double d = Math.Abs((FK_P[i] - FK_P[i - 1]).L2Norm() - LINK_LENGTH);
                if (d > 1e-15)
                {
                    //MessageBox.Show(String.Format("Link {0} is longer", d));
                    textBox.Text = String.Format("Link {0} is longer", d);

                }
            }
        } // UpdateIK

        private void slider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Angles[1][0] = slider_p1_x.Value;// ジョイント角度の更新
            Angles[1][1] = slider_p1_y.Value;// ジョイント角度の更新
            Angles[1][2] = slider_p1_z.Value;// ジョイント角度の更新

            Angles[2][0] = slider_p2_x.Value; // ジョイント角度の更新
            Angles[2][1] = slider_p2_y.Value; // ジョイント角度の更新
            Angles[2][2] = slider_p2_z.Value; // ジョイント角度の更新

            Angles[3][0] = slider_p3_x.Value; // ジョイント角度の更新
            Angles[3][1] = slider_p3_y.Value; // ジョイント角度の更新
            Angles[3][2] = slider_p3_z.Value; // ジョイント角度の更新

            Angles[4][0] = slider_p4_x.Value; // ジョイント角度の更新
            Angles[4][1] = slider_p4_y.Value; // ジョイント角度の更新
            Angles[4][2] = slider_p4_z.Value; // ジョイント角度の更新

            Angles[5][0] = slider_p5_x.Value; // ジョイント角度の更新
            Angles[5][1] = slider_p5_y.Value; // ジョイント角度の更新
            Angles[5][2] = slider_p5_z.Value; // ジョイント角度の更新

            Angles[6][0] = slider_p6_x.Value; // ジョイント角度の更新
            Angles[6][1] = slider_p6_y.Value; // ジョイント角度の更新
            Angles[6][2] = slider_p6_z.Value; // ジョイント角度の更新


            UpdateIK(); // FK再計算
            glControl_Update(); // 再描画

        } //slider_ValueChanged

    }
}
