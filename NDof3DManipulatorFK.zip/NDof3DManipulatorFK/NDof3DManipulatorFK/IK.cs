﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MathNet.Numerics.LinearAlgebra; // https://numerics.mathdotnet.com/Matrix.html

/*
 * 
 * 多軸マニュピュレータの数値計算
 * 
 * [仕様]
 *  1. 回転行列は、右ねじ方向が正
 *  2. 回転行列と並進行列は4x4
 * 
 * [使い方]
 *  var ik = new IK();
 *  const int N_JOINT = 6;
 *  const int N_LINK = N_JOINT; // リンク数 + 原点位置ベクトル
 * 
 *  // 各リンクの初期位置 [x,y,z]
 *  var Links = new Vector<double>[N_LINK]
 *  {
 *      Vector<double>.Build.DenseOfArray(new double[3] {0,0,0}),
 *      Vector<double>.Build.DenseOfArray(new double[3] {0,0,1}),
 *      Vector<double>.Build.DenseOfArray(new double[3] {0,0,1}),};
 *  
 *  // 初期角度 [rad]
 *  var Angles = new Vector<double>[N_JOINT]{
 *      Vector<double>.Build.DenseOfArray(new double[3] {0,0,0}),
 *      Vector<double>.Build.DenseOfArray(new double[3] {0,0,0}),
 *      Vector<double>.Build.DenseOfArray(new double[3] {0,0,0}),};
 *  
 *  // 順運動学計算
 *  Vector<double>[] P = ik.ForwardKinematic(N_LINK, Links, Angles);
 *
 *   
 */

namespace NDof3DManipulatorFK
{
    public class IK
    {
        //int ITERATION_NUMBER = 500;

        // ゼロベクトル
        public Vector<double> V0 = Vector<double>.Build.DenseOfArray(new double[4] { 0, 0, 0, 1 });

        // コンストラクタ
        public IK() { }

        // フォワードキネマティック
        public Vector<double>[] ForwardKinematic(int N, Vector<double>[] Links, Vector<double>[] Angles)
        {
            // 各リンクの初期位置 [x,y,z]
            Vector<double>[] P = new Vector<double>[Links.Length];

            Matrix<double> TransFormMatrix = Matrix<double>.Build.DenseIdentity(4);
            Vector<double> Pi = Vector<double>.Build.Dense(3);

            for (int i = 0; i < Links.Length; i++)
            {
                // 課題 :　掛ける順序を再確認
                TransFormMatrix = T(Links[i]) * Rxyz(Angles[i]) * TransFormMatrix;
                //TransFormMatrix = T(Links[i]) * Rx(Angles[i][0]) * Ry(Angles[i][1]) * Rz(Angles[i][2]) * TransFormMatrix;
                Pi = Vec4To3(V0 * TransFormMatrix);
                P[i] = Pi;

            }
            return P;
        }

        // Util Vec4to3
        public Vector<double> Vec4To3(Vector<double> V4)
        {
            var r = Vector<double>.Build.DenseOfArray(new double[3] { V4[0], V4[1], V4[2] });
            return r;
        }

        // S
        public Matrix<double> S(double sx, double sy, double xz)
        {
            Matrix<double> Li = Matrix<double>.Build.Dense(4, 4, 0);
            return Li;
        }

        // T
        public Matrix<double> T(double tx, double ty, double tz)
        {
            Matrix<double> r = Matrix<double>.Build.DenseOfArray(new double[4, 4]
                    {
                        {  1,  0,  0,  0},
                        {  0,  1,  0,  0},
                        {  0,  0,  1,  0},
                        { tx, ty, tz,  1}});
            return r;
        }
        // T オーバーライド
        public Matrix<double> T(Vector<double> Vt)
        {
            double tx = Vt[0];
            double ty = Vt[1];
            double tz = Vt[2];
            return T(tx, ty, tz);
        }
        // Rx
        // v' = v*Rx
        public Matrix<double> Rx(double rad)
        {
            Matrix<double> r = Matrix<double>.Build.DenseOfArray(new double[4, 4]
                    {
                        { 1,               0,              0,      0},
                        { 0,   Math.Cos(rad),   Math.Sin(rad),     0},
                        { 0, - Math.Sin(rad),   Math.Cos(rad),     0},
                        { 0,               0,              0,      1}});
            return r;
        }
        // Ry
        public Matrix<double> Ry(double rad)
        {
            Matrix<double> r = Matrix<double>.Build.DenseOfArray(new double[4, 4]
                    {
                        { Math.Cos(rad), 0, -Math.Sin(rad),     0},
                        { 0,             1,              0,     0},
                        { Math.Sin(rad), 0,  Math.Cos(rad),     0},
                        { 0,             0,              0,     1}});
            return r;
        }
        // Rz
        public Matrix<double> Rz(double rad)
        {
            Matrix<double> r = Matrix<double>.Build.DenseOfArray(new double[4, 4]
                    {
                    {  Math.Cos(rad),  Math.Sin(rad), 0,     0},
                    { -Math.Sin(rad),  Math.Cos(rad), 0,     0},
                    { 0,               0,             1,     0},
                    { 0,               0,             0,     1} });
            return r;
        }
        // Rxyz
        public Matrix<double> Rxyz(Vector<double> rads)
        {
            Matrix<double> r = Rx(rads[0]) * Ry(rads[1]) * Rz(rads[2]);
            return r;
        }
        public Matrix<double> Rxyz(double[] rads)
        {
            Matrix<double> r = Rx(rads[0]) * Ry(rads[1]) * Rz(rads[2]);
            return r;
        }
        public Matrix<double> Rxyz(double radx, double rady, double radz)
        {
            Matrix<double> r = Rx(radx) * Ry(rady) * Rz(radz);
            return r;
        }

    }

}
