﻿



using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// Numeric
/// https://numerics.mathdotnet.com/Matrix.html
using MathNet.Numerics.LinearAlgebra;

namespace _WpfApplicationOpenTKTemplate1
{
    public class IK
    {
        public IK() { }
        # region

        # endregion
        int ITERATION_NUMBER = 500;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Links">double(l1,l2)</param>
        /// <param name="Thetas">double(th1,th2)</param>
        /// <returns>(x1,y1,x2,y2)</returns>
        public double[] ForwardKinematic(double[] Links, double[] Thetas)
        {
            double l1 = Links[0];
            double l2 = Links[1];
            double th1 = Thetas[0];
            double th2 = Thetas[1];

            // 基準座標
            var X0 = Vector<double>.Build.DenseOfArray(new double[] { 0.0, 0.0, 1.0 });

            Vector<double> X_l1 = Rz(th1) * MatL(l1) * X0;
            Vector<double> X_l2 = Rz(th1) * MatL(l1) * Rz(th2) * MatL(l2) * X0;

            double[] ret = new double[4] { X_l1[0], X_l1[1], X_l2[0], X_l2[1] };
            return ret;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="Xp">目標位置{x,y}</param>
        /// <param name="Links">リンク長さ{l1,l2}</param>
        /// <param name="Thetas">初期角度[deg]{th1,th2}</param>
        /// <returns>theta : deg double(th1,th2)</returns>
        public double[] InverseKinematic(double[] Xp, double[] Links, double[] Thetas)
        {
            double l1 = Links[0];
            double l2 = Links[1];

            // 仮の解
            double th1 = Thetas[0];
            double th2 = Thetas[1];

            // 行列準備
            var x0 = Vector<double>.Build.Dense(3);
            var dX = Vector<double>.Build.Dense(3);
            var Xg = Vector<double>.Build.Dense(2);
            var X = Vector<double>.Build.DenseOfArray(Xp); // {xp, yp}
            var P = Matrix<double>.Build.Dense(2, 3);
            var J1 = Vector<double>.Build.Dense(3);
            var J2 = Vector<double>.Build.Dense(3);
            var JJ = Matrix<double>.Build.Dense(3, 2);
            var J = Matrix<double>.Build.Dense(2, 2);
            var invJ = Matrix<double>.Build.Dense(2, 2);
            var th = Vector<double>.Build.Dense(2);

            for (int j = 0; j < ITERATION_NUMBER; j++)
            {

                x0 = Vector<double>.Build.DenseOfArray(new double[] { 0, 0, 1 }); // 原点座標
                P = Matrix<double>.Build.DenseOfArray(new double[,] { { 1, 0, 0 }, { 0, 1, 0 } }); // 3次元から2次元へ射影
                // 現在の手先位置を求める
                Xg = P * Rz(th1) * MatL(l1) * Rz(th2) * MatL(l2) * x0; // {xg, yg}

                // ヤコビ行列を求める
                J1 = dRz(th1) * MatL(l1) * x0; // {j11,j12,j13}
                J2 = Rz(th1) * MatL(l1) * dRz(th2) * MatL(l2) * x0; // {j21,j22,j23}
                JJ = Matrix<double>.Build.DenseOfColumnVectors(J1, J2); //3つの列ベクトルを連結する

                J = P * JJ; // ヤコビ行列

                invJ = J.Transpose() * (J * J.Transpose()).Inverse(); //ヤコビ行列の逆行列

                dX = X - Xg;  // 位置の変位量 {xp,yp}-{xg,yg}

                th = 0.01 * invJ * dX;

                th1 = th1 + th[0];
                th2 = th2 + th[1];

            }

            double[] ret = new double[2] { th1, th2 };
            return ret;
        }

        /// <summary>
        /// 並進行列(x軸方向に並進)
        /// </summary>
        /// <param name="l"></param>
        /// <returns></returns>
        public Matrix<double> MatL(double l)
        {
            Matrix<double> Li = Matrix<double>.Build.DenseOfArray(new double[,] {
                                                                { 1, 0, l }, 
                                                                { 0, 1, 0 }, 
                                                                { 0, 0, 1 } });
            return Li;
        }

        public Matrix<double> Rz(double rad)
        {
            // double rad = Math.PI * (th / 180.0);
            Matrix<double> R = Matrix<double>.Build.DenseOfArray(new double[,] {
                                                { Math.Cos(rad), -1.0 * Math.Sin(rad), 0.0 }, 
                                                { Math.Sin(rad), Math.Cos(rad), 0 }, 
                                                { 0, 0, 1 } });
            return R;
        } // Rz
        public Matrix<double> dRz(double rad)
        {
            // double rad = Math.PI * (th / 180.0);
            Matrix<double> R = Matrix<double>.Build.DenseOfArray(new double[,] {
                                                { -1.0*Math.Sin(rad), -1.0 * Math.Cos(rad), 0.0 }, 
                                                { Math.Cos(rad), -1.0 * Math.Sin(rad), 0 }, 
                                                { 0, 0, 0.0 } });
            return R;
        } // dRz
    }

}
