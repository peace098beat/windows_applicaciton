﻿
using SharpDX.DirectInput;
using System;
using System.Collections.Generic;
using System.Windows;


namespace _WpfApplicationOpenTKTemplate1
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {

        // IK test
        public IK ik = new IK();
        public double x1 = 0;
        public double y1 = 0;
        public double z1 = 0;
        public double x2 = 0;
        public double y2 = 0;
        public double z2 = 0;

        double[] Links = new double[] { 3, 3 }; // リンク長さ
        double[] Xp = new double[] { 0, 0 }; // 目標位置
        double[] rads = new double[] { Math.PI / 4.0, Math.PI / 4.0 }; //初期間接角度(deg)

        Joystick joystick = null;

        public MainWindow()
        {
            InitializeComponent();


            DirectInput input = new DirectInput();
            List<Joystick>
                sticks = new List<Joystick>();



            foreach (DeviceInstance device in input.GetDevices(DeviceClass.GameControl, DeviceEnumerationFlags.AttachedOnly))
            {
                joystick = new Joystick(input, device.InstanceGuid);
                joystick.Acquire();

                foreach (DeviceObjectInstance deviceObject in joystick.GetObjects(DeviceObjectTypeFlags.Axis))
                {
                    joystick.GetObjectPropertiesById(deviceObject.ObjectId).Range = new InputRange(-100, 100);
                }
                sticks.Add(joystick);
            }

            if (joystick == null)
            {
                // are a fail message to appear on screen if no game pad present
                MessageBox.Show("stic null");
                return;
            }




        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            // IK再計算
            UpdateIK();
            // 再描画
            glControl_Update();
        }

        private void UpdateIK()
        {
            //Inverse Kinematic
            rads = ik.InverseKinematic(Xp, Links, rads);
            //Inverse Kinematic
            double[] positions = ik.ForwardKinematic(Links, rads);
            // Update Arm Position
            this.x1 = positions[0];
            this.y1 = positions[1];
            this.x2 = positions[2];
            this.y2 = positions[3];
        }

        private void SliderX_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            LabelXSlider.Content = e.NewValue.ToString();
            // ターゲット位置更新
            Xp[0] = e.NewValue;
            // IK再計算
            UpdateIK();
            // 再描画
            glControl_Update();
        }

        private void SliderY_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            LabelYSlider.Content = e.NewValue.ToString();
            // ターゲット位置更新
            Xp[1] = e.NewValue;
            // IK再計算
            UpdateIK();
            // 再描画
            glControl_Update();


        }

        private void Window_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == System.Windows.Input.Key.Down) SliderY.Value -= 0.1;
            if (e.Key == System.Windows.Input.Key.Up) SliderY.Value += 0.1;
            if (e.Key == System.Windows.Input.Key.Left) SliderX.Value -= 0.1;
            if (e.Key == System.Windows.Input.Key.Right) SliderX.Value += 0.1;
            if (e.Key == System.Windows.Input.Key.Enter)
            {
                UpdateIK();
                glControl_Update();
            }
            //var state = joystick.GetCurrentState();
            //var Vx = state.AngularVelocityX;

            //SliderY.Value += Vx;

        }




    }
}
